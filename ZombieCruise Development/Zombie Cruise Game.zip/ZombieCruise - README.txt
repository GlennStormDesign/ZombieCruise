+---------------------+
|                     |
|    Zombie Cruise    |
|                     |
+---------------------+

 a text adventure
  comedy / horror game
   for Windows OS
    by Glenn Storm
     December 2019

 [C++, Code::Blocks]

== To play:

this game uses typed 
 player commands

type 'help' for a list
 of commands

type 'quit' to exit

== Dev notes:

this project challenge:
 32 bytes working mem
 32 hours develop time
 (ended up ~42hrs)

although >2600 lines,
 most code lines are
 either comments/notes
 or hard-coded text

source code exposed as
 pdf with highlighting

notes here include many
 REVISIONs to design to
 redo mem layout and 
 find more mem (many!)